@include('admin.incs.header')
@include('admin.incs.sidebar')
@include('admin.incs.navbar')
@yield('content')

@include('admin.incs.footer')