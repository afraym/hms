<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <title>Maintenance</title>
</head>
<body style="text-align:center;">
    <h1>Site under maintenance.</h1>
        <br>
         <h1 dir="rtl">عدي علينا بكرا.</h1>
           <!-- Default Statcounter code for hms
https://hms.afraym.com/ -->
<script type="text/javascript">
var sc_project=13136548; 
var sc_invisible=1; 
var sc_security="baf81df5"; 
</script>
<script type="text/javascript"
src="https://www.statcounter.com/counter/counter.js"
async></script>
<noscript><div class="statcounter"><a title="Web Analytics"
href="https://statcounter.com/" target="_blank"><img
class="statcounter"
src="https://c.statcounter.com/13136548/0/baf81df5/1/"
alt="Web Analytics"
referrerPolicy="no-referrer-when-downgrade"></a></div></noscript>
<!-- End of Statcounter Code -->
</body>
</html>